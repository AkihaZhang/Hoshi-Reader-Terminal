#!/bin/sh
set -eu
APP_DIR="$HOME/.local/share/hoshi-reader-terminal/app"
BIN_DIR="$HOME/.local/bin"
mkdir -p "$APP_DIR" "$BIN_DIR"
cp "$(dirname "$0")/hoshi-terminal.pyz" "$APP_DIR/hoshi-terminal.pyz"
cat > "$BIN_DIR/hoshi" <<'EOF'
#!/bin/sh
exec python3 "$HOME/.local/share/hoshi-reader-terminal/app/hoshi-terminal.pyz" "$@"
EOF
cp "$BIN_DIR/hoshi" "$BIN_DIR/hoshi-terminal"
chmod +x "$BIN_DIR/hoshi" "$BIN_DIR/hoshi-terminal"
echo "已安装到 $BIN_DIR/hoshi"
echo "如果命令不可用，请把 $BIN_DIR 加入 PATH。"
