@echo off
chcp 65001 >nul
set SCRIPT_DIR=%~dp0
set TARGET=%LOCALAPPDATA%\HoshiReaderTerminal\bin
if not exist "%TARGET%" mkdir "%TARGET%"
copy /Y "%SCRIPT_DIR%hoshi-terminal.pyz" "%TARGET%\hoshi-terminal.pyz" >nul
(
  echo @echo off
  echo py "%%LOCALAPPDATA%%\HoshiReaderTerminal\bin\hoshi-terminal.pyz" %%*
  echo if errorlevel 9009 python "%%LOCALAPPDATA%%\HoshiReaderTerminal\bin\hoshi-terminal.pyz" %%*
) > "%TARGET%\hoshi-terminal.cmd"
(
  echo @echo off
  echo py "%%LOCALAPPDATA%%\HoshiReaderTerminal\bin\hoshi-terminal.pyz" %%*
  echo if errorlevel 9009 python "%%LOCALAPPDATA%%\HoshiReaderTerminal\bin\hoshi-terminal.pyz" %%*
) > "%TARGET%\hoshi.cmd"
echo Installed to %TARGET%
echo Add this folder to PATH if you want to run hoshi anywhere.
pause
