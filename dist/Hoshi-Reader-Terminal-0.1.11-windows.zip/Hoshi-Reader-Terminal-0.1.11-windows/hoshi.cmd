@echo off
chcp 65001 >nul
set SCRIPT_DIR=%~dp0
py -3 "%SCRIPT_DIR%hoshi-terminal.pyz" %*
if errorlevel 9009 (
  python "%SCRIPT_DIR%hoshi-terminal.pyz" %*
)
